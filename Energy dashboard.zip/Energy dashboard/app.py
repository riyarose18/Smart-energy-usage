import streamlit as st
import pandas as pd
from sklearn.cluster import KMeans
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Smart Energy Dashboard", layout="wide")

# -------------------- Load Data --------------------
data = pd.read_csv("energy_data.csv")

day_map = {
    "Monday": 1,
    "Tuesday": 2,
    "Wednesday": 3,
    "Thursday": 4,
    "Friday": 5,
    "Saturday": 6,
    "Sunday": 7
}

data["Day_Num"] = data["Day"].map(day_map)
data["Type"] = data["Day"].apply(lambda x: "Weekend" if x in ["Saturday", "Sunday"] else "Weekday")

# -------------------- Sidebar --------------------
st.sidebar.title("Filters")

selected_days = st.sidebar.multiselect(
    "Select Days",
    options=data["Day"].tolist(),
    default=data["Day"].tolist()
)

selected_type = st.sidebar.selectbox(
    "Select Type",
    ["All", "Weekday", "Weekend"]
)

scale = st.sidebar.slider(
    "Simulate Usage Increase (%)",
    min_value=0,
    max_value=50,
    value=0
)

# -------------------- Filter Data --------------------
filtered = data[data["Day"].isin(selected_days)].copy()

if selected_type != "All":
    filtered = filtered[filtered["Type"] == selected_type].copy()

filtered["Energy_Usage"] = filtered["Energy_Usage"] * (1 + scale / 100)

# -------------------- KMeans --------------------
if len(filtered) >= 2:
    X = filtered[["Day_Num", "Energy_Usage"]]
    kmeans = KMeans(n_clusters=2, random_state=0, n_init=10)
    filtered["Cluster"] = kmeans.fit_predict(X).astype(str)
else:
    filtered["Cluster"] = "0"

# -------------------- Metrics --------------------
total_usage = round(filtered["Energy_Usage"].sum(), 2)
avg_usage = round(filtered["Energy_Usage"].mean(), 2) if len(filtered) > 0 else 0

weekday_usage = round(
    filtered[filtered["Type"] == "Weekday"]["Energy_Usage"].sum(), 2
)

weekend_usage = round(
    filtered[filtered["Type"] == "Weekend"]["Energy_Usage"].sum(), 2
)

weekend_percent = round((weekend_usage / total_usage) * 100, 1) if total_usage != 0 else 0
estimated_saving = round(weekend_usage * 0.3, 2)
efficiency_score = max(0, int(100 - weekend_percent))

# -------------------- Header --------------------
st.markdown(
    """
    <h1 style='text-align:center; color:#1f4e79;'>⚡ Smart Energy Usage Dashboard</h1>
    <h4 style='text-align:center; color:gray;'>Admin Building Energy Analysis (Weekday vs Weekend)</h4>
    """,
    unsafe_allow_html=True
)

# -------------------- Top Insight --------------------
if len(filtered) > 0:
    max_day_row = filtered.loc[filtered["Energy_Usage"].idxmax()]
    st.info(
        f"Highest energy usage observed on **{max_day_row['Day']}** with **{round(max_day_row['Energy_Usage'],2)} units**."
    )

# -------------------- Tabs --------------------
tab1, tab2, tab3 = st.tabs(["Dashboard", "Analysis", "Insights"])

# ==================== TAB 1 ====================
with tab1:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Usage", total_usage)
    c2.metric("Average Usage", avg_usage)
    c3.metric("Weekend Usage %", f"{weekend_percent}%")
    c4.metric("Estimated Saving", estimated_saving)

    col1, col2 = st.columns(2)

    with col1:
        fig_bar = px.bar(
            filtered,
            x="Day",
            y="Energy_Usage",
            color="Type",
            text="Energy_Usage",
            title="Daily Energy Usage"
        )
        fig_bar.update_traces(textposition="outside")
        st.plotly_chart(fig_bar, use_container_width=True)

    with col2:
        fig_line = px.line(
            filtered,
            x="Day",
            y="Energy_Usage",
            markers=True,
            title="Weekly Energy Trend"
        )
        st.plotly_chart(fig_line, use_container_width=True)

# ==================== TAB 2 ====================
with tab2:
    col3, col4 = st.columns(2)

    with col3:
        if len(filtered) > 0:
            fig_pie = px.pie(
                filtered,
                names="Type",
                values="Energy_Usage",
                hole=0.45,
                title="Weekday vs Weekend Distribution"
            )
            st.plotly_chart(fig_pie, use_container_width=True)

    with col4:
        if len(filtered) > 0:
            fig_scatter = px.scatter(
                filtered,
                x="Day_Num",
                y="Energy_Usage",
                color="Cluster",
                size="Energy_Usage",
                hover_name="Day",
                symbol="Type",
                title="K-Means Clustering of Usage"
            )
            st.plotly_chart(fig_scatter, use_container_width=True)

    fig_gauge = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=weekend_percent,
            title={"text": "Weekend Usage %"},
            gauge={"axis": {"range": [0, 100]}}
        )
    )
    st.plotly_chart(fig_gauge, use_container_width=True)

    st.subheader("Energy Efficiency Score")
    st.progress(efficiency_score)
    st.write(f"Efficiency Score: **{efficiency_score}/100**")

# ==================== TAB 3 ====================
with tab3:
    st.subheader("Key Insights")
    st.write("1. Weekdays show higher energy consumption compared to weekends.")
    st.write("2. Weekend usage is lower, but still indicates unnecessary energy consumption.")
    st.write("3. K-means clustering separates high-usage and low-usage patterns clearly.")
    st.write("4. Simulation slider helps in performing what-if analysis for future usage increase.")

    st.subheader("Recommendations")
    st.write("1. Install auto switch-off systems for lights and equipment on weekends.")
    st.write("2. Use smart HVAC scheduling based on occupancy.")
    st.write("3. Monitor idle systems to reduce unnecessary power consumption.")
    st.write("4. Implement weekend energy-saving policies for admin buildings.")

    st.subheader("Conclusion")
    st.success(
        "This dashboard shows that energy optimization is possible by reducing unnecessary weekend consumption and improving smart scheduling."
    )

# -------------------- Download Button --------------------
st.download_button(
    label="Download Filtered Report",
    data=filtered.to_csv(index=False),
    file_name="energy_report.csv",
    mime="text/csv"
)